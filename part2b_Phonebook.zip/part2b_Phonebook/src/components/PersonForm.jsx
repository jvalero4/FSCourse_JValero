import { useState } from 'react'

const PersonForm = ({persons, setPersons, setPersonsFiltered, personsFiltered}) => {

    const [newName, setNewName] = useState('')
    const [newNumber, setNewNumber] = useState('')
  
    const onNameChange = (event) => {
      setNewName(event.target.value)
    }
  
    const onNumberChange = (event) => {
      setNewNumber(event.target.value)
    }
  
    const addPerson = (event) => {
      event.preventDefault()
      if(persons.map(person => person.name).includes(newName)) {
        alert(newName + ' is already added to phonebook')
        setNewName('')
        setNewNumber('')
        return
      }else{
        const nameObject = {
          name: newName,
          number: newNumber
        }
        setPersons(persons.concat(nameObject))
        setPersonsFiltered(personsFiltered.concat(nameObject))
        setNewName('')
        setNewNumber('')
      }
      
    }
  
    return(
      <form onSubmit={addPerson}>
          <div>
            name: <input value={newName} onChange = {onNameChange} />
          </div>
          <div>
            number: <input value={newNumber} onChange = {onNumberChange} />
          </div>
          <div>
            <button type="submit">add</button>
          </div>
        </form>
    )
  }

export default PersonForm