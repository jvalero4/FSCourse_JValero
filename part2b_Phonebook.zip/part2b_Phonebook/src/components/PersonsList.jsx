import { useState } from 'react'

const PersonList = () => {
}

export default PersonList