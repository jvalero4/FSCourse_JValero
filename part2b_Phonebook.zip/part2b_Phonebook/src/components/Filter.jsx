import { useState } from 'react'
import App from '../App'

const Filter = () => {

    const [personsFiltered, setPersonsFiltered] = useState(App.person)

    const onFilterChange = (event) => {
        const value = event.target.value;
        setFilteredName(value)
        setPersonsFiltered(App.persons.filter(person => person.name.toLowerCase().includes(value.toLowerCase())))
    }


    return (
    <form>
        <div>
            filter shown with <input value= {filteredName} onChange= {onFilterChange} />
        </div>
    </form>
    )
}

export default Filter
