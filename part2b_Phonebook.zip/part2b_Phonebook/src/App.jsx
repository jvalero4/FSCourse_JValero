import { useState } from 'react'

const Person = (props) => {
  return(
    <li>{props.name} {props.number}</li>
  )
}

const PersonForm = ({persons, setPersons, setPersonsFiltered, personsFiltered}) => {

  const [newName, setNewName] = useState('')
  const [newNumber, setNewNumber] = useState('')

  const onNameChange = (event) => {
    setNewName(event.target.value)
  }

  const onNumberChange = (event) => {
    setNewNumber(event.target.value)
  }

  const addPerson = (event) => {
    event.preventDefault()
    if(persons.map(person => person.name).includes(newName)) {
      alert(newName + ' is already added to phonebook')
      setNewName('')
      setNewNumber('')
      return
    }else{
      const nameObject = {
        name: newName,
        number: newNumber
      }
      setPersons(persons.concat(nameObject))
      setPersonsFiltered(personsFiltered.concat(nameObject))
      setNewName('')
      setNewNumber('')
    }
    
  }

  return(
    <form onSubmit={addPerson}>
        <div>
          name: <input value={newName} onChange = {onNameChange} />
        </div>
        <div>
          number: <input value={newNumber} onChange = {onNumberChange} />
        </div>
        <div>
          <button type="submit">add</button>
        </div>
      </form>
  )
}

const Filter = ({persons, setPersonsFiltered}) => {
  const [filteredName, setFilteredName] = useState('')

  const onFilterChange = (event) => {
    const value = event.target.value;
    setFilteredName(value)
    setPersonsFiltered(persons.filter(person => person.name.toLowerCase().includes(value.toLowerCase())))
  }

  return(
    <form>
        <div>
          filter shown with <input value= {filteredName} onChange= {onFilterChange} />
        </div>
    </form>
  )
}

const App = () => {
  const [persons, setPersons] = useState([
    { name: 'Arto Hellas', number: '040-123456', id: 1 },
    { name: 'Ada Lovelace', number: '39-44-5323523', id: 2 },
    { name: 'Dan Abramov', number: '12-43-234345', id: 3 },
    { name: 'Mary Poppendieck', number: '39-23-6423122', id: 4 }
  ])
  const [personsFiltered, setPersonsFiltered] = useState(persons)

  return (
    <div>
      <h2>Phonebook</h2>
      <Filter persons = {persons} setPersonsFiltered = {setPersonsFiltered}/>
      <h2>add a new</h2>
      <PersonForm persons = {persons} setPersons= {setPersons} setPersonsFiltered = {setPersonsFiltered} personsFiltered = {personsFiltered}/>
      <h2>Numbers</h2>
      <ul>
        {personsFiltered.map(person =>
          <Person key={person.name} name={person.name} number={person.number} />)}
      </ul>
    </div>
  )
}

export default App