
const Button = (props) => (
    <button onClick={props.handleClick}> 
      {props.text}
    </button>
  )

const handleClick = (selectedCountries,setSelectedCountries,clickedCountry) => (
    setSelectedCountries(selectedCountries.filter(country => country.name.common.toLowerCase().includes(clickedCountry.toLowerCase())))
)

const CountriesList = ({selectedCountries,setSelectedCountries,weatherCountry}) => {
    
    const countryInfo = () => {
        return(
        <div>
            {selectedCountries.map((country, index) =>
            <div key={index}>
                <h1>{country.name.common}</h1>
                    Capital: {country.capital}
                    <br/> 
                    Area: {country.area}
                    <br/>
                <h3>Languages:</h3>
                <ul>
                    {Object.entries(country.languages).map(([code, language]) => (
                    <li key={code}>
                        {language}
                    </li>
                    ))}
                </ul>
                <img src={country.flags.png}/>
                <h3>Weather in {country.name.common}</h3>
                Temperature {weatherCountry.main ? (weatherCountry.main.temp - 273.15).toFixed(2) : ''} Celcius
                <br />
                <img src= {weatherCountry.weather ? `https://openweathermap.org/img/wn/${weatherCountry.weather[0].icon}.png` : ''}/>
                <br />
                Wind {weatherCountry.wind ? weatherCountry.wind.speed : ''} m/s
            </div>)}
            <br/>
        </div>
        )
    }

    if(selectedCountries.length > 10){
        return (
            <div>
                Too many matches, specify another filter
            </div>
        )
    }else if(selectedCountries.length === 1){
        return countryInfo()
    }else if(selectedCountries.length === 0){
        return(
        <div>
            Search some country or countries
        </div>
    )
    }else{
        return (
            <div>
                <ul>
                    {selectedCountries.map(country => 
                        <li key={country.name.common}> {country.name.common} 
                        <Button handleClick={() => handleClick(selectedCountries,setSelectedCountries,country.name.common)} text='Show'/></li>
                    )}
                </ul>
            </div>
        )
    }

    /*switch (true) {
        case selectedCountries.length > 10:
            return (
                <div>
                    Too many matches, specify another filter
                </div>
            )
        case selectedCountries.length === 1:
            return countryInfo()
        case selectedCountries.length === 0:
            return (
                <div>Search some country or countries</div>
            )
        default:
            return (
                <div>
                    <ul>
                        {selectedCountries.map(country => 
                            <li key={country.name.common}> {country.name.common} 
                            <Button handleClick={() => handleClick(selectedCountries,setSelectedCountries,country.name.common)} text='Show'/></li>
                        )}
                    </ul>
                </div>
            )
    }*/

}

export default CountriesList
