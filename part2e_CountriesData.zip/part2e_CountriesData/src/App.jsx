import { useState,useEffect } from 'react'
import countriesServices from './services/countries'
import CountriesList from './components/CountriesList'
import './index.css'


const App = () => {
  const [value, setValue] = useState('')
  const [countriesInfo, setCountriesInfo] = useState([])
  const [selectedCountries, setSelectedCountries] = useState([])
  const [weatherCountry, setWeatherCountry] = useState([])

  const handleChange = (event) => {
    setValue(event.target.value)
  }

  useEffect(() => {
    countriesServices.getAll().then(response => {
      setCountriesInfo(response.data)
      setSelectedCountries(countriesInfo.filter(country => country.name.common.toLowerCase().includes(value.toLowerCase())))
    })
  }, [value])

  useEffect(() => {
    if (selectedCountries.length === 1) {
      countriesServices.getCountryWeatherAPI(selectedCountries.map(country => country.name.common))
        .then(response => {
          setWeatherCountry(response.data);
        });
    }
  }, [selectedCountries])  

  return (
    <div>
      <form>
        find countries <input value={value} onChange={handleChange} />
      </form>
      <CountriesList selectedCountries={selectedCountries} setSelectedCountries={setSelectedCountries} weatherCountry={weatherCountry} />
    </div>
  )
}

export default App