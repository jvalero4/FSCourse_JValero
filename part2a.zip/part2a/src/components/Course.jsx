const Course = ({courses}) => {
  return(
    <div>
      <Header/>
      <Content courses={courses}/>
    </div> 
  )
}

const Header = () => {
  return (
    <h1>Web development curriculum</h1>
  )
}

const Content = ({courses}) => {
  return (
    <div>
    {courses.map(course => (
      <div key={course.id}>
        <NameCourse name={course.name} />
          {course.parts.map(part => (
            <ul key={part.id}>
            <Part key={part.id} name={part.name} exercises={part.exercises} />
            </ul>
            
          ))}
        <Total parts={course.parts}/>
      </div>
      ))}
    </div>
  )
}

const Part = (props) => {
  return (
    <li>{props.name} {props.exercises}</li>
  )
}

const Total = ({parts}) => {
  const totalExercises = parts.map(part => part.exercises).reduce((acc, value) => acc + value,0)
  return (
    <div>
      <b>total of {totalExercises} exercises</b>

    </div>
  )
}

const NameCourse = ({name}) => {
  return(
  <h2>{name}</h2>
  )
}

export default Course