
import personsServices from './../services/persons'

const Person = (props) => {

  const Button = (props) => {
    return(
    <button onClick={props.handleClick}> 
      {props.text}
    </button>
    )
  }

  const handleDeletePerson = (person) => {
    personsServices.deletePerson(person.id, person.name).then(response => {
      props.setPersons(props.persons.filter(person => response.data.id !== person.id))
      props.setPersonsFiltered(props.personsFiltered.filter(person => response.data.id !== person.id))
      })
  }

  return(
    <ul>
      {props.personsFiltered.map((person) => <li key={person.name}>
      {person.name} {person.number} 
      <Button  handleClick ={() => handleDeletePerson(person)} text ="Delete"/>
      </li>
      )}
    </ul>
    
  )
}

export default Person