import { useState,useEffect } from 'react'
import Filter from './components/Filter'
import PersonForm from './components/PersonForm'
import Person from './components/Person'
import personsServices from './services/persons'

const App = () => {
  const [persons, setPersons] = useState([])
  const [personsFiltered, setPersonsFiltered] = useState([])

  useEffect(() => {
    personsServices.getAllPersons().then(response => {
      setPersons(response.data)
      setPersonsFiltered(response.data)
    })
  }, [])

  return (
    <div>
      <h2>Phonebook</h2>
      <Filter persons = {persons} setPersonsFiltered = {setPersonsFiltered}/>
      <h2>add a new</h2>
      <PersonForm persons = {persons} setPersons= {setPersons} setPersonsFiltered = {setPersonsFiltered} personsFiltered = {personsFiltered}/>
      <h2>Numbers</h2>
      <Person persons = {persons} setPersons= {setPersons} setPersonsFiltered = {setPersonsFiltered} personsFiltered = {personsFiltered}/>
    </div>
  )
}

export default App
